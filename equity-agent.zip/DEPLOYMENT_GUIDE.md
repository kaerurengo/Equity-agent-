# Equity Agent — Deployment Guide
## GitHub → Vercel → iPhone Home Screen

---

## 📁 Your Project File Structure

```
equity-agent/
├── index.html
├── package.json
├── vite.config.js
├── src/
│   ├── main.jsx
│   └── App.jsx
└── public/
    ├── manifest.json
    ├── icon-192.png
    └── icon-512.png
```

---

## STEP 1 — Create a GitHub Repository

1. Go to https://github.com and log in
2. Click the **"+"** icon (top-right) → **"New repository"**
3. Name it: `equity-agent`
4. Set to **Public**
5. Leave everything else blank (no README, no .gitignore)
6. Click **"Create repository"**

---

## STEP 2 — Upload Your Files to GitHub

On the empty repository page you'll see an "uploading an existing file" link.

1. Click **"uploading an existing file"**
2. Drag and drop ALL files from the `equity-agent/` folder:
   - `index.html`
   - `package.json`
   - `vite.config.js`

   Then create the subfolders by uploading them separately:

3. Click **"Add file" → "Upload files"** again
4. Before dropping files, type `src/` in the path box at the top, then upload:
   - `src/main.jsx`
   - `src/App.jsx`

5. Repeat for the public folder — type `public/` in the path box, then upload:
   - `public/manifest.json`
   - `public/icon-192.png`
   - `public/icon-512.png`

6. After each upload, scroll down and click **"Commit changes"**

---

## STEP 3 — Deploy on Vercel

1. Go to https://vercel.com and log in with your GitHub account
2. Click **"Add New Project"**
3. You'll see your `equity-agent` repo listed — click **"Import"**
4. Vercel will auto-detect it as a Vite project
5. Leave all settings as default
6. Click **"Deploy"**
7. Wait ~1 minute — Vercel will give you a live URL like:
   `https://equity-agent-xyz.vercel.app`

---

## STEP 4 — Add to iPhone Home Screen

1. Open **Safari** on your iPhone (must be Safari, not Chrome)
2. Go to your Vercel URL (e.g. `https://equity-agent-xyz.vercel.app`)
3. Tap the **Share button** (box with arrow, bottom of screen)
4. Scroll down and tap **"Add to Home Screen"**
5. Name it **"Equity Agent"** → tap **"Add"**

The app icon will appear on your home screen and launches fullscreen,
just like a native iPhone app. ✅

---

## STEP 5 — Future Updates

Whenever you want to update the app:
1. Edit the file on GitHub (open the file → click the pencil ✏️ icon)
2. Commit the change
3. Vercel automatically rebuilds and redeploys within ~30 seconds

---

## ⚠️ Important Note on the API Key

The app calls the Anthropic API for AI analysis. For the app to work,
you need to add your Anthropic API key. In Vercel:

1. Go to your project → **Settings → Environment Variables**
2. Add: `VITE_ANTHROPIC_API_KEY` = your key
3. Redeploy

Then in `src/App.jsx`, update the fetch headers to include:
```js
"x-api-key": import.meta.env.VITE_ANTHROPIC_API_KEY,
"anthropic-version": "2023-06-01",
"anthropic-dangerous-direct-browser-access": "true",
```

---

Good luck! 🚀
